<?php

declare(strict_types=1);

namespace Endroid\QrCode\ErrorCorrectionLevel;

final class ErrorCorrectionLevelQuartile implements ErrorCorrectionLevelInterface
{
}
