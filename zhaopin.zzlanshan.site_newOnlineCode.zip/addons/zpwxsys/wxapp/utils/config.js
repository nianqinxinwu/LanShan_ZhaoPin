
class Config{
    constructor(){

    }
}

Config.restUrl = 'http://192.168.3.253:8000/addons/zpwxsys/';
//Config.restUrl = 'https://fastadmin.site100.cn/addons/zpwxsys/';
Config.onPay=true;  //是否启用支付
 
export {Config};
