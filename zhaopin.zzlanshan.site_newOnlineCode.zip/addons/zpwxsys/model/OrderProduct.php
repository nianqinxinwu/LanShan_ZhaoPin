<?php

namespace addons\zpwxsys\model;



class OrderProduct extends BaseModel
{
//    protected $autoWriteTimestamp = true;
}
