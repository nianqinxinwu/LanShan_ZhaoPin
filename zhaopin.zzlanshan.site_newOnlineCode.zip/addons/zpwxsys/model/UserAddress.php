<?php

namespace addons\zpwxsys\model;


class UserAddress extends BaseModel
{
   protected $hidden =['id', 'delete_time', 'user_id'];

}


