<?php


namespace addons\zpwxsys\model;

class ProductProperty extends BaseModel
{
    protected $hidden=['product_id', 'delete_time', 'id'];
}